from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote,urlsplit
from fractions import Fraction
import struct
root=Path(__file__).resolve().parents[1]/'dist'
class Doc(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='a' and 'href' in d:self.links.append(d['href'])
docs={}
for p in root.glob('*.html'):
 d=Doc();d.feed(p.read_text());assert len(set(d.ids))==len(d.ids),p;docs[p.name]=d
for name,d in docs.items():
 for link in d.links:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  target=unquote(u.path) or name
  if target=='/':target='index.html'
  assert (root/target).exists(),(name,target)
  if u.fragment and target in docs:assert u.fragment in docs[target].ids,(name,link)
assert struct.pack('>f',-13.25).hex()=='c1540000'
assert struct.unpack('<i',bytes.fromhex('f4ffffff'))[0]==-12
assert struct.unpack('>f',bytes.fromhex('40400000'))[0]==3
assert -Fraction(1*16+13,16)==Fraction(-29,16)
def align(n,a):return (n+a-1)//a*a
solutions=[(a,b) for a in range(1,40) for b in range(1,40) if align(b,4)==8 and align(12+2*a,8)==32 and align(4*a*b,8)==184]
assert solutions==[(9,5)],solutions
cache=[[],[]];hits=0
for addr in [2,23,13,9,20,15,13,10]:
 block=addr//4;s=block%2;t=block//2
 if t in cache[s]:hits+=1;cache[s].remove(t)
 elif len(cache[s])==2:cache[s].pop(0)
 cache[s].append(t)
assert hits==4
assert (root/'CNAME').read_text().strip()=='blog.zjzj.work'
assert not list(root.glob('*.pdf'))
print(f'PASS: {len(docs)} HTML pages, all internal links/anchors, floating encodings, layout constraints, LRU, publication boundary')
