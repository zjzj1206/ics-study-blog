#!/usr/bin/env python3
"""Build a portable static study blog. Sources remain editable Markdown."""
from pathlib import Path
from markdown_it import MarkdownIt
import html,re,shutil,json,zipfile
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'dist'
# Rebuild only generated output so removed chapters cannot survive a build.
if OUT.exists(): shutil.rmtree(OUT)
OUT.mkdir()
md=MarkdownIt('commonmark',{'html':False}).enable('table')
pages=[]
for path in sorted((ROOT/'content').glob('*.md')):
 text=path.read_text(); title=text.splitlines()[0].removeprefix('# ')
 pages.append({'id':path.stem,'title':title,'text':text,'file':path.stem+'.html'})

def render(text):
 body=md.render(text);toc=[];counter=0
 def heading(m):
  nonlocal counter
  counter+=1;tag,content=m.group(1),m.group(2);anchor='section-'+str(counter)
  toc.append((anchor,re.sub('<[^>]+>','',content)))
  return f'<h{tag} id="{anchor}">{content}<a class="anchor" href="#{anchor}" aria-label="链接到本节">#</a></h{tag}>'
 body=re.sub(r'<h([23])>(.*?)</h\1>',heading,body)
 body=body.replace('<table>','<div class="table-scroll"><table>').replace('</table>','</table></div>')
 return body,toc

def shell(title,body,active='',toc=(),prevnext=''):
 nav=''.join(f'<a {"aria-current=page" if p["id"]==active else ""} href="{p["file"]}">{html.escape(p["title"])}</a>' for p in pages)
 contents=''.join(f'<a href="#{a}">{t}</a>' for a,t in toc)
 return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)} · ZJZJ / ICS</title><meta name="description" content="北京大学 ICS 复习手册：课程知识、公式推导、边界情况、小班拓展与往年题导航。"><link rel="stylesheet" href="style.css"><link rel="icon" href="favicon.svg" type="image/svg+xml"></head><body><a class="skip" href="#main">跳到正文</a><header><a class="brand" href="index.html">ZJZJ<span> / ICS NOTES</span></a><div class="header-right"><a href="https://blog.zjzj.work/">学习空间</a><a href="all.html">整本阅读</a><button type="button" onclick="window.print()">打印</button><button id="menu" aria-expanded="false" aria-controls="chapters">目录</button></div></header><div class="layout"><nav id="chapters" aria-label="章节目录"><div class="nav-label">2026 · 复习手册</div>{nav}<div class="nav-foot">依据本地课件与公开题库<br>更新于 2026.10.01</div></nav><main id="main"><div class="eyebrow">COMPUTER SYSTEMS · PEKING UNIVERSITY</div>{body}{prevnext}<footer>理解表示，追踪执行。<span><a href="14-coverage.html">资料来源与覆盖范围</a></span></footer></main><aside aria-label="本页目录"><div class="nav-label">本页内容</div>{contents}<a href="#main">回到顶部 ↑</a></aside></div><script src="app.js"></script></body></html>'''
for i,p in enumerate(pages):
 body,toc=render(p['text'])
 pn='<div class="pager">'+(f'<a href="{pages[i-1]["file"]}">上一章<br>{html.escape(pages[i-1]["title"])}</a>' if i else '<span></span>')+(f'<a href="{pages[i+1]["file"]}">下一章<br>{html.escape(pages[i+1]["title"])}</a>' if i+1<len(pages) else '')+'</div>'
 (OUT/p['file']).write_text(shell(p['title'],body,p['id'],toc,pn))
count=sum(len(re.findall(r'[\u4e00-\u9fff]',p['text'])) for p in pages)
cards=''.join(f'<a class="chapter-card" href="{p["file"]}"><span class="chapter-number">{p["title"].split(" · ")[0] if " · " in p["title"] else "00"}</span><div><h2>{html.escape(p["title"].split(" · ")[-1])}</h2><p>{"课程主线" if 1<=int(p["id"][:2])<=8 else "阅读与查漏"}</p></div><span aria-hidden="true">↗</span></a>' for p in pages)
home=f'''<section class="intro"><div class="edition">AUTUMN 2026 <span>学习笔记 / 01</span></div><h1>计算机系统导论<br><em>期中复习手册</em></h1><p class="lead">从一个比特，到一段程序的执行。按章节梳理概念、推导、易错边界与真题方法。</p><div class="stats"><span><b>{len(pages)}</b> 个章节</span><span><b>{count//1000}k+</b> 中文字</span><span><b>7 + 6</b> 课件与小班资料</span></div></section><section class="scope-note"><strong>先对齐考试范围</strong><p>课件日程：10 月 12 日第一次阶段测验考第 1～8 讲。现有课件到第 7 讲；第 8 讲按教材与 2025 试卷补充。本手册限定为第 1～8 讲及对应小班内容。</p><a href="00-guide.html">阅读范围说明</a></section><div class="section-heading"><h2>章节目录</h2><span>按顺序读，也可以直接查阅</span></div><section class="chapter-grid">{cards}</section>'''
(OUT/'index.html').write_text(shell('计算机系统导论复习手册',home))
combined='\n\n---\n\n'.join(p['text'] for p in pages)
body,toc=render(combined)
(OUT/'all.html').write_text(shell('整本复习手册',body,toc=toc))
(OUT/'404.html').write_text(shell('页面不存在','<h1>这一页没有找到</h1><p>请从章节目录继续阅读。</p><a href="index.html">回到 ICS 首页</a>'))
for path in (ROOT/'assets').iterdir():shutil.copy2(path,OUT/path.name)
(OUT/'.nojekyll').touch()
(ROOT/'复习资料汇总.md').write_text(combined)
print(json.dumps({'pages':len(pages),'chinese_characters':count,'output':str(OUT)},ensure_ascii=False))

shutil.copy2(ROOT/'README.md',OUT/'README.md')
with zipfile.ZipFile(OUT/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path in [ROOT/'build.py',ROOT/'README.md',ROOT/'requirements.txt',ROOT/'复习资料汇总.md',*(ROOT/'content').glob('*.md'),*(ROOT/'assets').glob('*'),*(ROOT/'checks').glob('*.py')]:
  z.write(path,path.relative_to(ROOT))
