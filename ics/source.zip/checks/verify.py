from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote,urlsplit
from fractions import Fraction
import struct
root=Path(__file__).resolve().parents[1]/'dist'
class Doc(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.ids=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='a' and 'href' in d:self.links.append(d['href'])
docs={}
for p in root.glob('*.html'):
 d=Doc();d.feed(p.read_text());assert len(set(d.ids))==len(d.ids),p;docs[p.name]=d
for name,d in docs.items():
 for link in d.links:
  u=urlsplit(link)
  if u.scheme or u.netloc:continue
  target=unquote(u.path) or name
  if target=='/':target='index.html'
  assert (root/target).exists(),(name,target)
  if u.fragment and target in docs:assert u.fragment in docs[target].ids,(name,link)
assert struct.pack('>f',-13.25).hex()=='c1540000'
assert struct.unpack('<i',bytes.fromhex('f4ffffff'))[0]==-12
assert struct.unpack('>f',bytes.fromhex('40400000'))[0]==3
assert -Fraction(1*16+13,16)==Fraction(-29,16)
def align(n,a):return (n+a-1)//a*a
solutions=[(a,b) for a in range(1,40) for b in range(1,40) if align(b,4)==8 and align(12+2*a,8)==32 and align(4*a*b,8)==184]
assert solutions==[(9,5)],solutions
assert not (root/'CNAME').exists(), 'Custom domain belongs to the study hub'
for removed in ['09-architecture','10-optimization','11-memory']:
 assert not (root/(removed+'.html')).exists(), removed
from markdown_it import MarkdownIt
md=MarkdownIt('commonmark',{'html':False}).enable('table')
for p in (root.parent/'content').glob('*.md'):
 tokens=md.parse(p.read_text())
 for t in tokens:
  if t.type=='inline' and '\n' in t.content:
   assert not any(l.startswith('|') for l in t.content.splitlines()), (p,t.map,'Unparsed table')
# Table separators, inline code punctuation and escaped bitwise/logical OR.
fixture = "|表达式|说明|\n|---|---|\n|`x \\| y`|按位或|\n|`a \\|\\| b`|逻辑或|\n|`int *(*A[2])[3]`|声明|\n|`-1 < 1u`|比较|\n"
rendered=md.render(fixture)
assert '<code>x | y</code>' in rendered
assert '<code>a || b</code>' in rendered
assert '<code>int *(*A[2])[3]</code>' in rendered
assert '<code>-1 &lt; 1u</code>' in rendered
assert rendered.count('<td>')==8
integers=(root/'02-integers.html').read_text()
assert '<code>-1 &lt; 1u</code></td>' in integers
assert integers.count('<table>')==6  # Original tables plus shift, conversion and arithmetic-model examples
assert '<code>int *(*A[2])[3]</code></td>' in (root/'07-data.html').read_text()
assert '旧期中扩展' not in (root/'all.html').read_text()
assert not list(root.glob('*.pdf'))
print(f'PASS: {len(docs)} HTML pages, all internal links/anchors, floating encodings, layout constraints, table regressions, standard scope and publication boundary')
